<html>
	<head>
		<title>
			Create New User Account
		</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="index.css" />
	</head>
	<body>
    <nav>
        <div class="nav__logo">AA Airlines</div>
        <button class="btn"><a href="/Customer/login_page.php">Login</a></button>
    </nav>
    <header class="section__container header__container">
        <h1 class="section__header">New user successfully registered! Login into your account to book tickets.</h1>
    </header>
	</body>
</html>